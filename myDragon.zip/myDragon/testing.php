	<?php
      session_start();
      if(!isset($_SESSION['username'])){
            header("Location: login.php");
            die;
      }
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>myDragon - Naga</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/sb-admin.css" rel="stylesheet">
    <link href="css/plugins/morris.css" rel="stylesheet">
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body>

    <div id="wrapper">
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.html">myDragon</a>
            </div>
            <ul class="nav navbar-right top-nav">
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-bell"></i> <b class="caret"></b></a>
                    <ul class="dropdown-menu alert-dropdown">
                        <?php
                        include "connect.php";
                        $query = "CALL sp_usr_data('$_SESSION[username]')";
                        $sql = mysqli_query($db, $query);
                        $row = mysqli_fetch_array($sql);
                        $count=$row["usr_jumlah_naga"];
                        while ($count>0){ $count--;
                            echo "<li>
                                    <a href='#'>(notifikasi) <span class='label label-default'>Alert Badge</span></a>
                                </li>";
                        }
                        ?>
                    </ul>
                </li>
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-user"></i>  <?php $username = $_SESSION['username']; echo $username;?> <b class="caret"></b></a>
                    <ul class="dropdown-menu">
                        <li>
                            <p>&nbsp;&nbsp;<i class="fa fa-fw fa-money"></i>&nbsp;<?php echo $row["usr_uang"]; ?></p>
                        </li>
                        <li class="divider"></li>
                        <li>
                            <a href="logout.php"><i class="fa fa-fw fa-power-off"></i> Log Out</a>
                        </li>
                    </ul>
                </li>
            </ul>
            <!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
            <div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav side-nav">
                    <li>
                        <a href="index.php"><i class="fa fa-fw fa-home"></i> Home</a>
                    </li>
                    <li>
                        <a href="#"><i class="fa fa-fw fa-shopping-bag"></i> Shop</a>
                    </li>
                    <li>
                        <a href="#"><i class="fa fa-fw fa-info"></i> About</a>
                    </li>
                </ul>
            </div>
        </nav>

        <div id="page-wrapper">
                <div id="page-wrapper">

            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                            Dragons
                        </h1>
                    </div>
                </div>

                <div class="row">
                 <?php
                    include 'connect.php';
                            $SQLCommand = "CALL sp_naga_data('$username')";
                                    $result = mysqli_query($db,$SQLCommand);
                                    $yourArray = array();
                                    while($row2 = mysqli_fetch_assoc($result)){
                                         #var_dump($row);
                                         #echo "<p>$row[naga_ID]</p>";
                                         #echo "<p>$row[usr_ID]</p>";
                                         #echo "<p>$row[spesies_ID]</p>";
                                         #echo "<p></p>";
                                         #echo "<p>$row[naga_tgl_lahir]</p>";                
                         echo "<div class='col-lg-3 col-md-6'>
                            <div class='panel panel-yellow'>
                                <div class='panel-heading'>
                                    <div class='row'>
                                        <div class='col-xs-3'>
                                            <img src='$row2[image]'>
                                        </div>
                                        <div class='col-xs-9 text-right'>
                                           <div><h2>$row2[naga_nama]</h2></div>
                                            <div>$row2[spesies_nama]</div>
                                            <div>"; ?>
                                                <?php 
                                                    if($row2["lapar"]>=50 && $row2["senang"]>=50){
                                                        echo "Senang dan Kenyang";
                                                    }
                                                    else if($row2["lapar"]>=50 && $row2["senang"]<50){
                                                        echo "Sedih tapi Kenyang";
                                                    }
                                                    else if($row2["lapar"]<50 && $row2["senang"]>=50){
                                                        echo "Senang tapi Lapar";
                                                    }
                                                    else if($row2["lapar"]<50 && $row2["senang"]<50){
                                                        echo "Sedih dan Lapar";
                                                    }

                                                ?><?php echo"
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <a href='#'>
                                    <div class='panel-footer'>
                                        <a href='testing.php' class='pull-left'>Tampilkan naga</a>
                                        <span class='pull-right'><i class='fa fa-arrow-circle-right'></i></span>
                                        <div class='clearfix'></div>
                                    </div>
                                </a>
                            </div>
                        </div>"; 
                    
                ?>

                </div>
                <ol class="breadcrumb">
                            <li class="active">
                                <i class="fa fa-desktopashboard"></i>Your dragons
                            </li>
                </ol>

<table style="width: 1080px; height: 800px; margin-left: auto; margin-right: auto;" border="1">
<tbody>
<tr style="height: 40px;">
<td style="height: 660px; width: 8px;" rowspan="13"><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /></td>
<td style="height: 40px; width: 68px;">&nbsp;</td>
<td style="height: 40px; width: 68.8px;">&nbsp;</td>
<td style="height: 660px; width: 8.8px;" rowspan="13"><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /></td>
<td style="height: 40px; width: 81.6px;">&nbsp;</td>
<td style="height: 40px; width: 56px;">&nbsp;</td>
<td style="height: 40px; width: 119.2px;">&nbsp;</td>
<td style="height: 40px; width: 117.6px;">&nbsp;</td>
<td style="height: 40px; width: 98.4px;">&nbsp;</td>
<td style="height: 40px; width: 48.8px;">&nbsp;</td>
</tr>
<tr style="height: 84px;">
<td style="height: 95px; width: 142.4px; text-align: center; vertical-align: middle;" colspan="2" rowspan="2"><br /><br />Item 1<br /><br /></td>
<td style="height: 84px; width: 81.6px;">&nbsp;</td>
<td style="height: 157px; width: 408px; text-align: center; vertical-align: middle;" colspan="4" rowspan="3"><img src="<?php echo $row2['image']?>"></td>
<td style="height: 84px; width: 48.8px;">&nbsp;</td>
</tr>
<tr style="height: 11px;">
<td style="height: 11px; width: 81.6px;">&nbsp;</td>
<td style="height: 11px; width: 48.8px;">&nbsp;</td>
</tr>
<tr style="height: 62px;">
<td style="height: 62px; width: 68px;">&nbsp;</td>
<td style="height: 62px; width: 68.8px;">&nbsp;</td>
<td style="height: 62px; width: 81.6px;">&nbsp;</td>
<td style="height: 62px; width: 48.8px;">&nbsp;</td>
</tr>
<tr style="height: 42px;">
<td style="height: 101px; width: 142.4px; text-align: center; vertical-align: middle;" colspan="2" rowspan="2"><br />Item 2<br /><br /><br /></td>
<td style="height: 42px; width: 81.6px;">&nbsp;</td>
<td style="height: 42px; width: 56px;">&nbsp;</td>
<td style="height: 42px; width: 119.2px;">&nbsp;</td>
<td style="height: 42px; width: 117.6px;">&nbsp;</td>
<td style="height: 42px; width: 98.4px;">&nbsp;</td>
<td style="height: 42px; width: 48.8px;">&nbsp;</td>
</tr>
<tr style="height: 59px;">
<td style="height: 59px; width: 81.6px;">&nbsp;</td>
<td style="height: 59px; width: 180.8px;" colspan="2"><br />&nbsp;Nama Naga</td>
<td style="height: 59px; width: 221.6px;" colspan="2">
<p>&nbsp;<?php echo "$row2[naga_nama]" ?></p>
</td>
<td style="height: 59px; width: 48.8px;">&nbsp;</td>
</tr>
<tr style="height: 54px;">
<td style="height: 54px; width: 68px;">&nbsp;</td>
<td style="height: 54px; width: 68.8px;">&nbsp;</td>
<td style="height: 54px; width: 81.6px;">&nbsp;</td>
<td style="height: 54px; width: 180.8px;" colspan="2">&nbsp;Spesies</td>
<td style="height: 54px; width: 221.6px;" colspan="2">&nbsp;<?php echo "$row2[spesies_nama]" ?></td>
<td style="height: 54px; width: 48.8px;">&nbsp;</td>
</tr>
<tr style="height: 54px;">
<td style="height: 108px; width: 142.4px; text-align: center; vertical-align: middle;" colspan="2" rowspan="2"><br /><br />Item 3<br /><br /></td>
<td style="height: 54px; width: 81.6px;">&nbsp;</td>
<td style="height: 54px; width: 180.8px;" colspan="2">&nbsp;Stage</td>
<td style="height: 54px; width: 221.6px;" colspan="2">&nbsp;
<?php 
    if($row2["naga_level"]==0){
        echo "Telur";
    }
    else if($row2["naga_level"]>=1 && $row2["naga_level"]<=5){
        echo "Bayi";
    }
    else if($row2["naga_level"]>=6 && $row2["naga_level"]<=10){
        echo "Anak-anak";
    }
    else if($row2["naga_level"]>=11 && $row2["naga_level"]<=15){
        echo "Remaja";
    }
    else if($row2["naga_level"]>=16 && $row2["naga_level"]<=20){
        echo "Dewasa";
    }
    else if($row2["naga_level"]>=21){
        echo "Legendaris";
    }
?></td>
<td style="height: 54px; width: 48.8px;">&nbsp;</td>
</tr>
<tr style="height: 54px;">
<td style="height: 54px; width: 81.6px;">&nbsp;</td>
<td style="height: 54px; width: 180.8px;" colspan="2">&nbsp;Level</td>
<td style="height: 54px; width: 221.6px;" colspan="2">&nbsp;<?php echo "$row2[naga_level]" ?></td>
<td style="height: 54px; width: 48.8px;">&nbsp;</td>
</tr>
<tr style="height: 54px;">
<td style="height: 54px; width: 68px;">&nbsp;</td>
<td style="height: 54px; width: 68.8px;">&nbsp;</td>
<td style="height: 54px; width: 81.6px;">&nbsp;</td>
<td style="height: 54px; width: 180.8px;" colspan="2">&nbsp;Gender</td>
<td style="height: 54px; width: 221.6px;" colspan="2"><br />&nbsp;Naga Gender<br />&nbsp;</td>
<td style="height: 54px; width: 48.8px;">&nbsp;</td>
</tr>
<tr style="height: 52px;">
<td style="height: 105px; width: 142.4px; text-align: center; vertical-align: middle;" colspan="2" rowspan="2">&nbsp;Item 4</td>
<td style="height: 52px; width: 81.6px;">&nbsp;</td>
<td style="height: 52px; width: 180.8px;" colspan="2">&nbsp;Status</td>
<td style="height: 52px; width: 221.6px;" colspan="2">&nbsp;
<?php 
    if($row2["lapar"]>=50 && $row2["senang"]>=50){
        echo "Senang dan Kenyang";
    }
    else if($row2["lapar"]>=50 && $row2["senang"]<50){
        echo "Sedih tapi Kenyang";
    }
    else if($row2["lapar"]<50 && $row2["senang"]>=50){
        echo "Senang tapi Lapar";
    }
    else if($row2["lapar"]<50 && $row2["senang"]<50){
        echo "Sedih dan Lapar";
    }

?></td>
<td style="height: 52px; width: 48.8px;">&nbsp;</td>
</tr>
<tr style="height: 53px;">
<td style="height: 53px; width: 81.6px;">&nbsp;</td>
<td style="height: 53px; width: 180.8px; text-align: center; vertical-align: middle;" colspan="2">&nbsp;<?php echo "$row2[naga_tgl_lahir]" ?></td>
<td style="height: 53px; width: 221.6px; text-align: center; vertical-align: middle;" colspan="2">&nbsp;<?php echo "ID : $row2[naga_ID]" ?></td>
<td style="height: 53px; width: 48.8px;">&nbsp;</td>
</tr>
<tr style="height: 41px;">
<td style="height: 41px; width: 68px;">&nbsp;</td>
<td style="height: 41px; width: 68.8px;">&nbsp;</td>
<td style="height: 41px; width: 81.6px;">&nbsp;</td>
<td style="height: 41px; width: 56px;">&nbsp;</td>
<td style="height: 41px; width: 119.2px;">&nbsp;</td>
<td style="height: 41px; width: 117.6px;">&nbsp;</td>
<td style="height: 41px; width: 98.4px;">&nbsp;</td>
<td style="height: 41px; width: 48.8px;">&nbsp;</td>
</tr>
</tbody>
</table>
<br><br><br>
<?php }?>

    <!-- /#wrapper -->

    <footer class="text-center">
      <p style="color:white"><br>© myDragon Dev Team<br>2017<br></p>
    </footer>

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

    <!-- Morris Charts JavaScript -->
    <script src="js/plugins/morris/raphael.min.js"></script>
    <script src="js/plugins/morris/morris.min.js"></script>
    <script src="js/plugins/morris/morris-data.js"></script>

</body>

</html>
