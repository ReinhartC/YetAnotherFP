<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>
<h1>ini naga </h1>
 <a href="logout.php">Keluar</a>
</body>
</html>